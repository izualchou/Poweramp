# -*- coding: utf-8 -*-
"""Poweramp PEQ 配置档案管理与导出 CLI。

设备档案存储在当前工作区 peq-profiles/ 目录（每设备一个 JSON）。
导出目标：
  --target poweramp   -> .txt（Poweramp 主应用 Equalizer -> Presets -> Import）
  --target equalizer -> .json（Poweramp Equalizer 预设导入）
  --target both      -> 两者（默认）

用法示例：
  python peq_cli.py list-devices
  python peq_cli.py create-profile --name 主力IEM --device-type iem_dynamic \
      --preference bass_boost --intensity 1.2 --brand Moondrop --model Aria
  python peq_cli.py list-profiles
  python peq_cli.py show-profile --name 主力IEM
  python peq_cli.py edit-profile --name 主力IEM --preference bass_boost,vocal_forward
  python peq_cli.py set-active --name 主力IEM
  python peq_cli.py export --profile active --target both --out exports
  python peq_cli.py delete-profile --name 主力IEM --yes

仅使用 Python 标准库。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from peq_engine import (
    DEVICE_LIBRARY,
    PREFERENCE_LIBRARY,
    PeqError,
    TYPE_GRAPHIC,
    TYPE_HIGH_SHELF,
    TYPE_LOW_SHELF,
    TYPE_PEAK,
    TYPE_EXT_PEAK,
    TYPE_EXT_HIGH_SHELF,
    compute_peq,
    compute_preamp,
    has_errors,
    parse_library_file,
    render_equalizer_json,
    render_poweramp_txt,
)

PROFILE_DIR = Path.cwd() / "peq-profiles"

# Poweramp 内置预设库默认路径：工作区 settings/ 下的导出 JSON
# 可通过环境变量 POWERAMP_PRESETS_JSON 覆盖指向用户的真实库文件
DEFAULT_LIBRARY_PATH = Path.cwd() / "settings" / "Poweramp自带默认配置.json"


def _library_path() -> Path:
    override = os.environ.get("POWERAMP_PRESETS_JSON")
    if override:
        return Path(override)
    return DEFAULT_LIBRARY_PATH

# Windows 控制台中文输出保护
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _safe_filename(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|\s]+', "_", name).strip("_")


def _profile_path(name: str) -> Path:
    return PROFILE_DIR / f"{_safe_filename(name)}.json"


def _load_profiles() -> List[dict]:
    if not PROFILE_DIR.is_dir():
        return []
    out = []
    for p in sorted(PROFILE_DIR.glob("*.json")):
        try:
            out.append(json.loads(p.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError) as exc:
            print(f"警告: 无法读取档案 {p.name}: {exc}", file=sys.stderr)
    return out


def _save_profile(profile: dict) -> Path:
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    path = _profile_path(profile["name"])
    path.write_text(
        json.dumps(profile, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return path


def _require_profile(name: str) -> dict:
    path = _profile_path(name)
    if not path.is_file():
        existing = ", ".join(p["name"] for p in _load_profiles()) or "（无档案）"
        raise PeqError(f"档案 '{name}' 不存在。现有档案：{existing}")
    return json.loads(path.read_text(encoding="utf-8"))


def _recompute(profile: dict) -> dict:
    """按档案中的设备类型/偏好/自定义频段/风格重新计算 preset。"""
    genre_bands = []
    g = profile.get("genre")
    if g and g in GENRE_LIBRARY:
        genre_bands = GENRE_LIBRARY[g]["bands"]
    preset = compute_peq(
        profile["device_type"],
        profile["preference"],
        intensity=profile.get("intensity", 1.0),
        custom_bands=profile.get("custom_bands") or None,
        genre_bands=genre_bands or None,
    )
    label = profile.get("preset_label")
    if label:
        preset["name"] = label
    else:
        suffix = f" + 风格:{profile['genre']}" if profile.get("genre") else ""
        preset["name"] = f"{profile['name']}{suffix} - {preset['name']}"
    profile["preset"] = preset
    return profile


def _print_issues(preset: dict) -> bool:
    """打印校验问题；返回是否存在阻断性错误。"""
    issues = preset.get("warnings", [])
    for msg in issues:
        print(f"  [{msg.split(':', 1)[0]}] {msg.split(':', 1)[-1].strip()}")
    return has_errors(issues)


# ---------------------------------------------------------------------------
# 子命令
# ---------------------------------------------------------------------------
def cmd_list_devices(_: argparse.Namespace) -> int:
    print("支持的设备类型（--device-type 取值）：\n")
    for key, dev in DEVICE_LIBRARY.items():
        print(f"  {key:<22} {dev['name']}")
        print(f"  {'':22} 声学特征: {dev['fr_notes']}")
        print(f"  {'':22} 基准修正段数: {len(dev['correction'])}\n")
    print("听感偏好（--preference 取值，可逗号组合）：\n")
    for key, rule in PREFERENCE_LIBRARY.items():
        only = f"（仅 {', '.join(rule['only_for'])}）" if rule.get("only_for") else ""
        print(f"  {key:<22} {rule['label']}{only}")
    return 0


def cmd_create_profile(a: argparse.Namespace) -> int:
    if _profile_path(a.name).is_file():
        raise PeqError(f"档案 '{a.name}' 已存在，请用 edit-profile 修改")
    # 解析 genre 并交给 _recompute（PEQ 引擎）
    if a.genre:
        # 通过 preset['genre'] 临时携带，让 _recompute 透传给 engine
        pass
    profile = {
        "name": a.name,
        "device_type": a.device_type,
        "brand": a.brand or "",
        "model": a.model or "",
        "preference": a.preference,
        "intensity": a.intensity,
        "custom_bands": a.custom_band or [],
        "genre": a.genre or "",
        "note": a.note or "",
        "active": False,
        "created_at": _now(),
        "updated_at": _now(),
    }
    profile = _recompute(profile)
    _print_issues(profile["preset"])
    path = _save_profile(profile)
    print(f"已创建档案: {path}")
    _print_summary(profile)
    return 0


def _print_summary(profile: dict) -> None:
    preset = profile["preset"]
    tname_map = {TYPE_LOW_SHELF: "低架", TYPE_HIGH_SHELF: "高架", TYPE_GRAPHIC: "图示",
                 TYPE_PEAK: "峰值", TYPE_EXT_PEAK: "扩展峰", TYPE_EXT_HIGH_SHELF: "扩展高架"}
    print(f"\n预设: {preset['name']}")
    mode = "图示 (graphic)" if not preset.get("parametric", True) else "参数 (parametric)"
    print(f"preamp: {preset['preamp']:+.1f} dB，频段数: {len(preset['bands'])}，模式: {mode}")
    print(f"{'类型':<6}{'频率':>8}{'增益':>9}{'Q':>7}")
    for b in preset["bands"]:
        tname = tname_map.get(b["type"], f"?{b['type']}")
        print(f"{tname:<6}{b['frequency']:>6}Hz{b['gain']:>+8.1f}dB{b['q']:>7.2f}")


def cmd_list_profiles(_: argparse.Namespace) -> int:
    profiles = _load_profiles()
    if not profiles:
        print(f"暂无设备档案（目录: {PROFILE_DIR}）。用 create-profile 创建。")
        return 0
    print(f"设备档案（目录: {PROFILE_DIR}）：\n")
    print(f"{'*':<3}{'名称':<20}{'设备类型':<22}{'偏好':<32}{'preamp':>8}")
    for p in profiles:
        mark = "*" if p.get("active") else " "
        preset = p.get("preset", {})
        preamp = f"{preset.get('preamp', 0):+.1f}" if preset else "-"
        print(
            f"{mark:<3}{p['name'][:18]:<20}{p['device_type']:<22}"
            f"{p['preference'][:30]:<32}{preamp:>8}"
        )
    return 0


def cmd_show_profile(a: argparse.Namespace) -> int:
    profile = _require_profile(a.name)
    print(json.dumps(profile, ensure_ascii=False, indent=2))
    _print_summary(profile)
    return 0


def cmd_edit_profile(a: argparse.Namespace) -> int:
    profile = _require_profile(a.name)
    if profile.get("locked"):
        raise PeqError(
            f"档案 '{a.name}' 为锁定（locked）的定制方案（如 31 段设计），"
            "不支持 edit-profile 重算；请删除重建或手工调整后用 export 导出"
        )
    if a.device_type:
        profile["device_type"] = a.device_type
    if a.preference:
        profile["preference"] = a.preference
    if a.intensity is not None:
        profile["intensity"] = a.intensity
    if a.custom_band is not None:
        profile["custom_bands"] = a.custom_band
    if a.note is not None:
        profile["note"] = a.note
    profile["updated_at"] = _now()
    profile = _recompute(profile)
    _print_issues(profile["preset"])
    _save_profile(profile)
    print(f"已更新档案 '{profile['name']}'")
    _print_summary(profile)
    return 0


def cmd_set_active(a: argparse.Namespace) -> int:
    _require_profile(a.name)  # 确认存在
    for p in _load_profiles():
        p["active"] = p["name"] == a.name
        _save_profile(p)
    print(f"已切换激活设备: {a.name}")
    return 0


def cmd_delete_profile(a: argparse.Namespace) -> int:
    path = _profile_path(a.name)
    if not path.is_file():
        raise PeqError(f"档案 '{a.name}' 不存在")
    if not a.yes and input(f"确认删除档案 '{a.name}'？(y/N) ").strip().lower() != "y":
        print("已取消")
        return 0
    path.unlink()
    print(f"已删除档案 '{a.name}'")
    return 0


def cmd_export(a: argparse.Namespace) -> int:
    name = a.profile
    if name == "active":
        actives = [p for p in _load_profiles() if p.get("active")]
        if not actives:
            raise PeqError("没有激活的设备档案，请先 set-active，或用 --profile 指定名称")
        if len(actives) > 1:
            raise PeqError(f"存在多个激活档案: {', '.join(p['name'] for p in actives)}")
        name = actives[0]["name"]
    profile = _require_profile(name)

    # 导出前重算并校验（确保档案被手工编辑后仍安全）；
    # 锁定档案（locked，如 31 段定制设计）直接使用存储的 preset，不重算
    if profile.get("locked"):
        print("（锁定档案：使用存储的定制 preset，跳过重算）")
    else:
        profile = _recompute(profile)
        _save_profile(profile)
    if _print_issues(profile["preset"]):
        print("存在阻断性校验错误，已中止导出。请修正后重试。", file=sys.stderr)
        return 1

    preset = profile["preset"]
    out_dir = Path(a.out) if a.out else Path("exports")
    out_dir.mkdir(parents=True, exist_ok=True)
    base = _safe_filename(profile["name"])
    written: List[Path] = []

    if a.target in ("poweramp", "both"):
        f = out_dir / f"{base}-Poweramp.txt"
        f.write_text(render_poweramp_txt(preset), encoding="utf-8", newline="\n")
        written.append(f)
    if a.target in ("equalizer", "both"):
        f = out_dir / f"{base}-PowerampEQ.json"
        f.write_text(render_equalizer_json(preset), encoding="utf-8", newline="\n")
        written.append(f)

    for f in written:
        print(f"已导出: {f}")
    print(
        "\n导入方式：\n"
        "  .txt  -> Poweramp 主应用: 菜单 -> Equalizer -> Presets -> Import\n"
        "  .json -> Poweramp Equalizer: 预设列表 -> Import\n"
        "  （将文件复制到手机存储后选择对应文件）"
    )
    return 0


# ---------------------------------------------------------------------------
# 内置音乐风格库（基于 Poweramp 自带 18 条经典 graphic 预设的调音特征总结）
# ---------------------------------------------------------------------------
# 每条风格由典型频段增益描述 + 适用场景说明组成；不直接复用 Poweramp 预设本身
# （那是另一种渲染格式），而是抽象成"风格曲线"叠加到用户档案的 PEQ 之上。
GENRE_LIBRARY = {
    "rock":      {"label": "摇滚",   "desc": "低频鼓点饱满+中高频吉它/人声前移",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 80, "q": 0.7, "gain": 2.5},
                      {"type": TYPE_PEAK, "frequency": 250, "q": 1.0, "gain": -1.5},
                      {"type": TYPE_PEAK, "frequency": 2500, "q": 1.2, "gain": 1.5},
                      {"type": TYPE_PEAK, "frequency": 4000, "q": 1.4, "gain": 2.0},
                  ]},
    "pop":       {"label": "流行",   "desc": "V 形调音——低频稍抬、高频通透，人声自然",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 90, "q": 0.7, "gain": 1.5},
                      {"type": TYPE_PEAK, "frequency": 3500, "q": 1.4, "gain": 1.0},
                      {"type": TYPE_HIGH_SHELF, "frequency": 9000, "q": 0.7, "gain": 1.5},
                  ]},
    "classical": {"label": "古典",   "desc": "频响平直、低频大提琴丰满、高频弦乐顺滑",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 100, "q": 0.7, "gain": 1.0},
                      {"type": TYPE_PEAK, "frequency": 6000, "q": 1.5, "gain": 1.0},
                  ]},
    "jazz":      {"label": "爵士",   "desc": "中频厚实（萨克斯/钢琴）、低频紧凑、高频不刺",
                  "bands": [
                      {"type": TYPE_PEAK, "frequency": 350, "q": 1.0, "gain": 1.5},
                      {"type": TYPE_PEAK, "frequency": 2500, "q": 1.2, "gain": 1.0},
                      {"type": TYPE_PEAK, "frequency": 5500, "q": 2.0, "gain": -1.0},
                  ]},
    "dance":     {"label": "电子舞曲", "desc": "低频重击+超高频亮——俱乐部风",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 60, "q": 0.7, "gain": 3.5},
                      {"type": TYPE_PEAK, "frequency": 40, "q": 1.0, "gain": 2.0},
                      {"type": TYPE_HIGH_SHELF, "frequency": 12000, "q": 0.7, "gain": 2.0},
                  ]},
    "techno":    {"label": "Techno", "desc": "极低频突出、中频压暗、高频清脆",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 50, "q": 0.7, "gain": 4.0},
                      {"type": TYPE_PEAK, "frequency": 250, "q": 1.2, "gain": -2.0},
                      {"type": TYPE_PEAK, "frequency": 1000, "q": 1.4, "gain": -1.0},
                      {"type": TYPE_HIGH_SHELF, "frequency": 10000, "q": 0.7, "gain": 1.5},
                  ]},
    "live":      {"label": "Live 现场", "desc": "保留现场感与早期反射，中频饱满",
                  "bands": [
                      {"type": TYPE_PEAK, "frequency": 400, "q": 1.0, "gain": 1.5},
                      {"type": TYPE_PEAK, "frequency": 1800, "q": 1.2, "gain": 1.5},
                      {"type": TYPE_HIGH_SHELF, "frequency": 8000, "q": 0.7, "gain": 1.0},
                  ]},
    "soft":      {"label": "轻柔",   "desc": "整体温和、齿音收敛、长时间聆听不疲劳",
                  "bands": [
                      {"type": TYPE_PEAK, "frequency": 3500, "q": 2.0, "gain": -2.0},
                      {"type": TYPE_PEAK, "frequency": 7000, "q": 2.0, "gain": -1.5},
                      {"type": TYPE_LOW_SHELF, "frequency": 120, "q": 0.7, "gain": 1.0},
                  ]},
    "loudness":  {"label": "响度补偿", "desc": "小音量下补回 Fletcher-Munson 曲线两端感知损失",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 90, "q": 0.7, "gain": 4.0},
                      {"type": TYPE_HIGH_SHELF, "frequency": 9000, "q": 0.7, "gain": 3.0},
                  ]},
    "vocal":     {"label": "纯人声/播客", "desc": "1-5kHz 突出人声频段、低高频收敛",
                  "bands": [
                      {"type": TYPE_PEAK, "frequency": 300, "q": 1.0, "gain": -1.0},
                      {"type": TYPE_PEAK, "frequency": 2500, "q": 1.2, "gain": 2.5},
                      {"type": TYPE_PEAK, "frequency": 4500, "q": 1.5, "gain": 1.5},
                      {"type": TYPE_HIGH_SHELF, "frequency": 10000, "q": 0.7, "gain": -1.0},
                  ]},
    "flat":      {"label": "原声平直", "desc": "仅设备修正，不叠加风格（与 balanced 类似）",
                  "bands": []},
    "bass_extreme": {"label": "低频极端", "desc": "强低频强化（-2.4dB preamp 守削波），中高频压暗",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 90, "q": 0.7, "gain": 9.0},
                      {"type": TYPE_PEAK, "frequency": 500, "q": 1.4, "gain": -1.5},
                      {"type": TYPE_PEAK, "frequency": 1000, "q": 1.4, "gain": -1.5},
                  ]},
    "treble":    {"label": "高音强化", "desc": "高频空气感+镲片亮、低频略收",
                  "bands": [
                      {"type": TYPE_PEAK, "frequency": 4000, "q": 1.4, "gain": 6.0},
                      {"type": TYPE_HIGH_SHELF, "frequency": 10000, "q": 0.7, "gain": 9.0},
                  ]},
    "speaker_loud": {"label": "扬声器响亮（外放）",
                  "desc": "专为手机/小音箱外放：全频段 +3dB 配合 +7.2dB preamp 提升总体响度",
                  "bands": [
                      {"type": TYPE_LOW_SHELF, "frequency": 90, "q": 0.7, "gain": 3.0},
                      {"type": TYPE_HIGH_SHELF, "frequency": 10000, "q": 0.7, "gain": 3.0},
                  ]},
}


def cmd_list_genres(_: argparse.Namespace) -> int:
    print("音乐风格库（可与设备修正叠加使用，应用于偏好组合 'genre:<key>'）：\n")
    for key, rule in GENRE_LIBRARY.items():
        print(f"  {key:<16} {rule['label']:<10} {rule['desc']}")
    print("\n用法示例：peq_cli create-profile --name 古典HD800 --device-type open_headphone "
          "--preference 'genre:classical'")
    return 0


def cmd_search_headphone(a: argparse.Namespace) -> int:
    """在 Poweramp 库中按子串搜索设备专用预设。"""
    path = _library_path()
    if not path.is_file():
        raise PeqError(
            f"找不到 Poweramp 预设库：{path}\n请将 Poweramp 导出的预设 JSON 放到该路径，"
            "或用环境变量 POWERAMP_PRESETS_JSON 指定真实路径。"
        )
    query = " ".join(a.query).lower().strip()
    presets = parse_library_file(str(path))
    matches = [p for p in presets if query in p["name"].lower()]
    # 默认只显示"看起来像设备名"的预设（≥20 段），避免噪声
    if a.device_only:
        matches = [p for p in matches if len(p["bands"]) >= 20]
    print(f"在库中搜索 '{' '.join(a.query)}'（共 {len(presets)} 条预设，匹配 {len(matches)} 条）\n")
    print(f"{'名称':<48}{'段数':>6}{'preamp':>9}{'模式':>12}")
    for p in matches[: a.limit]:
        mode = "图示" if not p["parametric"] else "参数"
        print(f"{p['name'][:46]:<48}{len(p['bands']):>6}{p['preamp']:>+8.1f}{mode:>12}")
    if len(matches) > a.limit:
        print(f"\n…还有 {len(matches) - a.limit} 条未显示，加 --limit 提高显示数量")
    return 0


def _write_preset_files(profile: dict, out_dir: Path, targets: tuple) -> List[Path]:
    """按指定目标写出预设文件并返回路径列表（库加载专用，沿用 Poweramp 原 preamp 不重算）。"""
    out_dir.mkdir(parents=True, exist_ok=True)
    preset = profile["preset"]
    base = _safe_filename(profile["name"])
    written: List[Path] = []
    if "poweramp" in targets:
        f = out_dir / f"{base}-Poweramp.txt"
        f.write_text(render_poweramp_txt(preset), encoding="utf-8", newline="\n")
        written.append(f)
    if "equalizer" in targets:
        f = out_dir / f"{base}-PowerampEQ.json"
        f.write_text(render_equalizer_json(preset), encoding="utf-8", newline="\n")
        written.append(f)
    return written


def cmd_load_library_preset(a: argparse.Namespace) -> int:
    """从 Poweramp 库加载指定名称预设，直接写出（往返保真）。"""
    path = _library_path()
    if not path.is_file():
        raise PeqError(f"找不到 Poweramp 预设库：{path}")
    presets = parse_library_file(str(path))
    exact = [p for p in presets if p["name"] == a.name]
    if not exact:
        # 模糊建议
        suggestions = [p["name"] for p in presets if a.name.lower() in p["name"].lower()][:5]
        sug = f"最相近：{', '.join(suggestions)}" if suggestions else "（无相近预设）"
        raise PeqError(f"预设 '{a.name}' 不在库中。{sug}")
    if len(exact) > 1:
        # 库中同型号常见多个变体（balanced/bass/treble 等），取首条并提示
        print(f"提示: 库中存在 {len(exact)} 条同名 '{a.name}'，"
              f"采用首条（其余: {[p.get('preamp', 0) for p in exact[1:]]} 等 preamp 变体）")
    lib_preset = exact[0]
    # 包装为档案结构供统一处理
    profile = {
        "name": f"{a.name}-库",
        "device_type": "library",
        "brand": "", "model": "Poweramp 库预设",
        "preference": "library",
        "intensity": 1.0,
        "custom_bands": [],
        "note": "从 Poweramp 库导入（无损往返）",
        "active": False,
        "created_at": _now(), "updated_at": _now(),
        "locked": True,
        "preset": lib_preset,
    }
    _save_profile(profile)
    print(f"已导入库预设 '{a.name}'（{len(lib_preset['bands'])} 段，"
          f"模式: {'图示' if not lib_preset['parametric'] else '参数'}）")
    _print_issues(lib_preset)
    if a.out:
        written = _write_preset_files(profile, Path(a.out),
                                       ("poweramp", "equalizer") if a.target == "both"
                                       else (a.target,))
        for f in written:
            print(f"已导出: {f}")
    return 0


def _combine_presets(device_preset: dict, genre_bands: list, intensity: float) -> dict:
    """将设备专用 PEQ（来自库或计算）与风格频段叠加——优先按用户已生成的设备 preset 为主，
    在其 bands 后追加风格 bands 并由引擎合并 + 重算 preamp。"""
    from peq_engine import _merge_bands as _eng_merge
    combined_bands = list(device_preset["bands"]) + [
        {**b, "gain": round(float(b["gain"]) * intensity, 1)}
        for b in genre_bands
    ]
    combined_bands = _eng_merge(combined_bands)
    combined_bands.sort(key=lambda x: (x["frequency"], x["type"]))
    preamp = compute_preamp(combined_bands)
    return {
        "name": f"{device_preset['name']} + 风格",
        "preamp": preamp,
        "parametric": True,
        "bands": combined_bands,
    }


def cmd_apply_headphone(a: argparse.Namespace) -> int:
    """组合 Poweramp 库中的设备修正 + 风格预设，导出预设文件。"""
    path = _library_path()
    if not path.is_file():
        raise PeqError(f"找不到 Poweramp 预设库：{path}")
    presets = parse_library_file(str(path))
    matches = [p for p in presets if p["name"] == a.headphone]
    if not matches:
        suggestions = [p["name"] for p in presets if a.headphone.lower() in p["name"].lower()][:5]
        sug = f"最相近：{', '.join(suggestions)}" if suggestions else "（无相近预设）"
        raise PeqError(f"库中找不到 '{a.headphone}'。{sug}\n先用 search-headphone 查询")
    if len(matches) > 1:
        print(f"提示: 库中存在 {len(matches)} 条同名 '{a.headphone}'，采用首条")
    device_preset = matches[0]

    genre_bands = []
    if a.genre:
        if a.genre not in GENRE_LIBRARY:
            valid = ", ".join(GENRE_LIBRARY.keys())
            raise PeqError(f"未知风格 '{a.genre}'。可选: {valid}")
        genre_bands = GENRE_LIBRARY[a.genre]["bands"]

    if genre_bands:
        # 库设备为 graphic 时无法精确叠加为 parametric，需要先转为 parametric 风格
        if not device_preset.get("parametric", True):
            print(f"注意: 设备预设 '{a.headphone}' 为图示模式（graphic），"
                  "风格叠加仅影响参数部分，graphic 频段原样保留。")
        new_preset = _combine_presets(device_preset, genre_bands, a.intensity)
    else:
        # 不叠加风格：直接采用库预设为档案
        new_preset = {
            "name": a.headphone,
            "preamp": device_preset["preamp"],
            "parametric": device_preset.get("parametric", True),
            "bands": device_preset["bands"],
        }

    profile = {
        "name": a.name,
        "device_type": "library",
        "brand": "", "model": a.headphone,
        "preference": a.genre or "library",
        "intensity": a.intensity,
        "custom_bands": [],
        "note": f"库设备 '{a.headphone}' + 风格 '{a.genre or '(无)'}'",
        "active": False,
        "created_at": _now(), "updated_at": _now(),
        "locked": True,
        "preset": new_preset,
    }
    _save_profile(profile)
    print(f"已生成档案: {profile['name']}")
    _print_issues(new_preset)
    if a.out:
        written = _write_preset_files(profile, Path(a.out),
                                       ("poweramp", "equalizer") if a.target == "both"
                                       else (a.target,))
        for f in written:
            print(f"已导出: {f}")
    return 0


# ---------------------------------------------------------------------------
# 参数解析
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="peq_cli",
        description="Poweramp PEQ 设备档案管理与预设导出（详见技能 poweramp-peq-tuner）",
    )
    sub = ap.add_subparsers(dest="command", required=True)

    sub.add_parser("list-devices", help="列出规则库支持的设备类型与听感偏好").set_defaults(func=cmd_list_devices)

    p = sub.add_parser("create-profile", help="创建设备档案并计算 PEQ")
    p.add_argument("--name", required=True, help="档案名称（唯一）")
    p.add_argument("--device-type", required=True, choices=sorted(DEVICE_LIBRARY))
    p.add_argument("--preference", required=True, help="听感偏好，逗号分隔（见 list-devices）")
    p.add_argument("--intensity", type=float, default=1.0, help="偏好强度 0.5-2.0（默认 1.0）")
    p.add_argument("--brand", help="设备品牌（可选）")
    p.add_argument("--model", help="设备型号（可选）")
    p.add_argument("--note", help="备注（可选）")
    p.add_argument("--genre", choices=sorted(GENRE_LIBRARY),
                   help="叠加音乐风格曲线（见 list-genres）")
    p.add_argument("--custom-band", action="append", metavar="SPEC",
                   help="追加自定义频段 'TYPE freq gain q'，如 --custom-band 'PK 150 3.0 1.4'，可多次")
    p.set_defaults(func=cmd_create_profile)

    p = sub.add_parser("list-profiles", help="列出工作区全部设备档案").set_defaults(func=cmd_list_profiles)

    p = sub.add_parser("show-profile", help="查看档案完整 JSON 与参数摘要")
    p.add_argument("--name", required=True)
    p.set_defaults(func=cmd_show_profile)

    p = sub.add_parser("edit-profile", help="修改档案并重新计算 PEQ")
    p.add_argument("--name", required=True)
    p.add_argument("--device-type", choices=sorted(DEVICE_LIBRARY))
    p.add_argument("--preference", help="新的听感偏好（逗号分隔）")
    p.add_argument("--intensity", type=float)
    p.add_argument("--custom-band", action="append", metavar="SPEC",
                   help="替换自定义频段（可多次）；传空清除")
    p.add_argument("--note")
    p.set_defaults(func=cmd_edit_profile)

    p = sub.add_parser("set-active", help="切换激活设备（同时仅一个激活）")
    p.add_argument("--name", required=True)
    p.set_defaults(func=cmd_set_active)

    p = sub.add_parser("delete-profile", help="删除设备档案")
    p.add_argument("--name", required=True)
    p.add_argument("--yes", action="store_true", help="跳过确认")
    p.set_defaults(func=cmd_delete_profile)

    p = sub.add_parser("export", help="导出预设文件（默认双格式）")
    p.add_argument("--profile", required=True, help="档案名称或 'active'")
    p.add_argument("--target", choices=("poweramp", "equalizer", "both"), default="both")
    p.add_argument("--out", help="输出目录（默认 ./exports）")
    p.set_defaults(func=cmd_export)

    # --- 库感知命令组：Poweramp 内置预设库（设备专用 AutoEQ + 经典风格） ---
    sub.add_parser("list-genres", help="列出音乐风格库（用于 create-profile --genre）"
                   ).set_defaults(func=cmd_list_genres)

    p = sub.add_parser("search-headphone", help="在 Poweramp 库中按子串搜索设备预设")
    p.add_argument("query", nargs="+", help="搜索关键词（可多词，如 'BGVP Scale'）")
    p.add_argument("--limit", type=int, default=20, help="最多显示条数（默认 20）")
    p.add_argument("--device-only", action="store_true",
                   help="只显示设备专用预设（≥20 段），过滤风格预设")
    p.set_defaults(func=cmd_search_headphone)

    p = sub.add_parser("load-library-preset",
                       help="从 Poweramp 库加载指定名称预设（无损往返导出）")
    p.add_argument("--name", required=True, help="库内预设精确名称")
    p.add_argument("--target", choices=("poweramp", "equalizer", "both"), default="both")
    p.add_argument("--out", help="输出目录")
    p.set_defaults(func=cmd_load_library_preset)

    p = sub.add_parser("apply-headphone",
                       help="组合库中设备修正 + 风格，生成新档案并可选导出")
    p.add_argument("--name", required=True, help="新档案名称（唯一）")
    p.add_argument("--headphone", required=True, help="库内设备预设名称（精确）")
    p.add_argument("--genre", choices=sorted(GENRE_LIBRARY),
                   help="叠加音乐风格（可选；不填则只加载库设备）")
    p.add_argument("--intensity", type=float, default=1.0, help="风格强度 0.5-2.0")
    p.add_argument("--target", choices=("poweramp", "equalizer", "both"), default="both")
    p.add_argument("--out", help="输出目录")
    p.set_defaults(func=cmd_apply_headphone)

    return ap


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except PeqError as exc:
        print(f"错误: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
