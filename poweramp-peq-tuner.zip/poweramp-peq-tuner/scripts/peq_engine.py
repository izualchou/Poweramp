# -*- coding: utf-8 -*-
"""Poweramp PEQ 计算引擎。

确定性计算模块：设备规则库（DEVICE_LIBRARY）+ 听感偏好库（PREFERENCE_LIBRARY）
-> 滤波器参数合成 -> 频响网格评估 -> preamp 自动补偿 -> 声学合理性校验。

设计依据见技能 references/ 目录：
- device-profiles.md  （设备类型 -> 频响特征 -> 基准修正滤波器）
- eq-design-guide.md  （听感偏好 -> 滤波器设计原则、Q/preamp 法则）
- poweramp-formats.md（导出格式规范）

仅使用 Python 标准库。无第三方依赖。
"""
from __future__ import annotations

import math
from typing import List, Optional

# ---------------------------------------------------------------------------
# 滤波器类型常量（与 Poweramp Equalizer .json 的 type 字段一致）
#
# Poweramp Equalizer 支持 6 种类型：
#   0 = Low Shelf    低搁架
#   1 = High Shelf   高搁架
#   2 = Graphic band 图示频段（仅 parametric=false 时使用；Q 必须 0；由 EQ 实时合成响应曲线）
#   3 = Peak         峰值（参数 EQ 标准）
#   4 = Extended peak 扩展峰值（多见于 AutoEQ 32 段设备预设，Q 类似 peak）
#   5 = Extended shelf 扩展高架（多见于 AutoEQ 32 段设备预设，Q 类似 shelf）
#   4/5 在 Poweramp EQ 内部视为 parametric 扩展类型；本引擎在合成响应评估时
#   近似按 peak / high-shelf 处理（与 3/1 行为基本一致），并在导入往返时
#   透明保留全部字段（channels/color/type 不丢失）。
# ---------------------------------------------------------------------------
TYPE_LOW_SHELF = 0
TYPE_HIGH_SHELF = 1
TYPE_GRAPHIC = 2
TYPE_PEAK = 3
TYPE_EXT_PEAK = 4
TYPE_EXT_HIGH_SHELF = 5

TYPE_NAME = {
    TYPE_LOW_SHELF: "LSC",
    TYPE_HIGH_SHELF: "HSC",
    TYPE_GRAPHIC: "GR",
    TYPE_PEAK: "PK",
    TYPE_EXT_PEAK: "PK+",
    TYPE_EXT_HIGH_SHELF: "HSC+",
}
# 解析/校验/合成响应时映射到的主类型
_TYPE_AS_PEAK = {TYPE_PEAK, TYPE_EXT_PEAK}
_TYPE_AS_SHELF = {TYPE_HIGH_SHELF, TYPE_EXT_HIGH_SHELF}

# ---------------------------------------------------------------------------
# 声学约束（超出即视为无效/不安全预设；详见 eq-design-guide.md）
# ---------------------------------------------------------------------------
LIMITS = {
    "freq_min": 20,
    "freq_max": 20000,
    "gain_abs_max": 10.0,     # 单段增益硬上限
    "gain_abs_warn": 6.0,     # 单段增益警告线（需有明确声学理由）
    "peak_q_min": 0.4,
    "peak_q_max": 5.0,
    "shelf_q_min": 0.5,
    "shelf_q_max": 0.9,
    "bands_max": 16,          # 建议段数上限（主应用支持最多 128）
    "bands_recommend": 10,
    "intensity_min": 0.5,
    "intensity_max": 2.0,
    "preamp_margin_db": 0.5,  # preamp 安全余量
    "combined_gain_warn": 10.0,  # 合成正增益警告线
}

# ---------------------------------------------------------------------------
# 设备规则库（文档版见 references/device-profiles.md，扩展时两处同步）
# ---------------------------------------------------------------------------
DEVICE_LIBRARY = {
    "iem_dynamic": {
        "name": "入耳式 IEM（动圈）",
        "fr_notes": "低频易轰头；2.5-4kHz 入耳增益失调；8-10kHz 毛刺",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 60, "q": 1.0, "gain": -3.0},
            {"type": TYPE_PEAK, "frequency": 3000, "q": 1.4, "gain": 2.0},
            {"type": TYPE_PEAK, "frequency": 9000, "q": 3.0, "gain": -2.5},
        ],
    },
    "iem_ba": {
        "name": "入耳式 IEM（动铁）",
        "fr_notes": "低频量感偏少；4-6kHz 偏亮易齿音",
        "correction": [
            {"type": TYPE_LOW_SHELF, "frequency": 120, "q": 0.7, "gain": 2.5},
            {"type": TYPE_PEAK, "frequency": 5000, "q": 2.0, "gain": -2.0},
        ],
    },
    "iem_hybrid": {
        "name": "入耳式 IEM（圈铁混合）",
        "fr_notes": "低频足+高频亮；1-3kHz 衔接处易凹陷",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 60, "q": 1.0, "gain": -2.0},
            {"type": TYPE_PEAK, "frequency": 2000, "q": 1.2, "gain": 1.5},
            {"type": TYPE_PEAK, "frequency": 9000, "q": 3.0, "gain": -2.0},
        ],
    },
    "earbud": {
        "name": "平头耳塞",
        "fr_notes": "无密封低频严重泄漏；8-9kHz 谐振尖峰",
        "correction": [
            {"type": TYPE_LOW_SHELF, "frequency": 150, "q": 0.7, "gain": 5.0},
            {"type": TYPE_PEAK, "frequency": 8500, "q": 4.0, "gain": -3.0},
        ],
    },
    "closed_headphone": {
        "name": "封闭式头戴耳机",
        "fr_notes": "100-250Hz 驻波隆起；3-4kHz 起伏",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 180, "q": 1.1, "gain": -3.0},
            {"type": TYPE_PEAK, "frequency": 3500, "q": 1.4, "gain": 1.5},
        ],
    },
    "open_headphone": {
        "name": "开放式头戴耳机",
        "fr_notes": "频响相对平直；6-8kHz 常凹陷",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 7000, "q": 1.5, "gain": 1.5},
        ],
    },
    "bluetooth_headphone": {
        "name": "蓝牙头戴耳机（含降噪）",
        "fr_notes": "编解码高频劣化；出厂偏 V 形调音",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 80, "q": 0.9, "gain": -3.0},
            {"type": TYPE_PEAK, "frequency": 1000, "q": 1.2, "gain": 1.5},
            {"type": TYPE_HIGH_SHELF, "frequency": 9000, "q": 0.7, "gain": 2.0},
        ],
    },
    "bookshelf_speaker": {
        "name": "书架/桌面音箱",
        "fr_notes": "近场桌面反射染声；低频下潜有限",
        "correction": [
            {"type": TYPE_LOW_SHELF, "frequency": 90, "q": 0.7, "gain": 2.0},
            {"type": TYPE_PEAK, "frequency": 220, "q": 1.2, "gain": -2.0},
        ],
    },
    "monitor_speaker": {
        "name": "监听音箱",
        "fr_notes": "频响已平直，仅可微调",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 3000, "q": 1.4, "gain": 0.5},
        ],
    },
    "car_audio": {
        "name": "车载音响",
        "fr_notes": "座舱低频增益；路噪掩蔽；高音偏轴衰减",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 45, "q": 1.0, "gain": -3.0},
            {"type": TYPE_HIGH_SHELF, "frequency": 8000, "q": 0.8, "gain": 2.5},
            {"type": TYPE_PEAK, "frequency": 1000, "q": 1.0, "gain": 1.0},
        ],
    },
    "portable_speaker": {
        "name": "便携蓝牙音箱",
        "fr_notes": "低频弱；机身共振；高频窄且粗糙",
        "correction": [
            {"type": TYPE_LOW_SHELF, "frequency": 110, "q": 0.7, "gain": 4.0},
            {"type": TYPE_PEAK, "frequency": 650, "q": 1.5, "gain": -2.0},
            {"type": TYPE_HIGH_SHELF, "frequency": 10000, "q": 0.7, "gain": 1.5},
        ],
    },
    "phone_speaker": {
        "name": "手机立体声扬声器",
        "fr_notes": "微型单元 150Hz 以下物理无输出；中低频易薄'空洞'；高频窄",
        "correction": [
            {"type": TYPE_PEAK, "frequency": 250, "q": 1.0, "gain": 2.0},
            {"type": TYPE_PEAK, "frequency": 3150, "q": 1.4, "gain": 1.0},
        ],
    },
}

# ---------------------------------------------------------------------------
# 听感偏好库（文档版见 references/eq-design-guide.md 第 2 节）
# gain 会被 intensity 线性缩放后再应用。
# ---------------------------------------------------------------------------
PREFERENCE_LIBRARY = {
    "balanced": {
        "label": "均衡中性",
        "bands": [],  # 不叠加偏好，仅设备基准修正
    },
    "bass_boost": {
        "label": "低频增强",
        "bands": [
            {"type": TYPE_LOW_SHELF, "frequency": 80, "q": 0.7, "gain": 4.0},
        ],
        # IEM/耳塞类额外补一段次低频下潜（见 eq-design-guide.md 2.2）
        "extra_bands_iem": [
            {"type": TYPE_PEAK, "frequency": 40, "q": 1.0, "gain": 1.5},
        ],
    },
    "vocal_forward": {
        "label": "人声突出",
        "bands": [
            {"type": TYPE_PEAK, "frequency": 2800, "q": 1.2, "gain": 2.5},
            {"type": TYPE_PEAK, "frequency": 250, "q": 1.0, "gain": -1.5},
            {"type": TYPE_HIGH_SHELF, "frequency": 8000, "q": 0.7, "gain": -1.0},
        ],
    },
    "treble_airy": {
        "label": "高音通透",
        "bands": [
            {"type": TYPE_HIGH_SHELF, "frequency": 10000, "q": 0.7, "gain": 3.0},
            {"type": TYPE_PEAK, "frequency": 14000, "q": 2.0, "gain": 1.5},
        ],
    },
    "reduce_harshness": {
        "label": "减刺耳",
        "bands": [
            {"type": TYPE_PEAK, "frequency": 3500, "q": 2.0, "gain": -2.0},
            {"type": TYPE_LOW_SHELF, "frequency": 200, "q": 0.7, "gain": 1.5},
        ],
    },
    "warm": {
        "label": "温暖厚声",
        "bands": [
            {"type": TYPE_LOW_SHELF, "frequency": 150, "q": 0.7, "gain": 2.5},
            {"type": TYPE_PEAK, "frequency": 3000, "q": 1.4, "gain": -1.5},
        ],
    },
    "soundstage": {
        "label": "横向声场",
        "bands": [
            {"type": TYPE_PEAK, "frequency": 800, "q": 1.0, "gain": -1.0},
            {"type": TYPE_HIGH_SHELF, "frequency": 10000, "q": 0.7, "gain": 2.0},
        ],
    },
    "road_noise_high": {
        "label": "高速路噪补偿（车载专用）",
        "bands": [
            {"type": TYPE_LOW_SHELF, "frequency": 70, "q": 0.7, "gain": 3.0},
            {"type": TYPE_HIGH_SHELF, "frequency": 6000, "q": 0.8, "gain": 2.0},
        ],
        "only_for": ["car_audio"],
    },
}

_IEM_DEVICE_KEYS = {"iem_dynamic", "iem_ba", "iem_hybrid", "earbud"}


class PeqError(ValueError):
    """计算引擎输入错误（未知设备/偏好、参数超界等）。"""


# ---------------------------------------------------------------------------
# 频响近似评估
# ---------------------------------------------------------------------------
def _band_gain_at(band: dict, f: float) -> float:
    """单个滤波器在频率 f 处的近似 dB 贡献（用于合成评估与 preamp 计算）。

    扩展类型映射：TYPE_EXT_PEAK(4) 按 peak 处理；TYPE_EXT_HIGH_SHELF(5) 按 high-shelf 处理；
    TYPE_GRAPHIC(2) 返回 0.0 —— 其响应曲线由 Poweramp EQ 实时合成、本引擎无法解析，
    评估时会附加警告并忽略其对 preamp 的贡献（导入 graphic 预设时给出提示）。
    """
    fc = float(band["frequency"])
    gain = float(band["gain"])
    q = float(band["q"])
    if fc <= 0:
        return 0.0
    t = band["type"]
    if t in _TYPE_AS_PEAK:
        x = (f / fc - fc / f) * q
        return gain / (1.0 + x * x)
    if t == TYPE_LOW_SHELF:
        # 低架：f << fc 时贡献 ~gain，f >> fc 时 ~0，fc 处 ~0.5*gain
        r = f / fc
        return gain / (1.0 + r ** 4)
    if t in _TYPE_AS_SHELF:
        r = f / fc
        return gain * (r ** 4) / (1.0 + r ** 4)
    # TYPE_GRAPHIC 与其他未识别类型：保守返回 0，调用方负责提示
    return 0.0


def _freq_grid(points_per_octave: int = 12) -> List[float]:
    f_min, f_max = LIMITS["freq_min"], LIMITS["freq_max"]
    n = int(math.log2(f_max / f_min) * points_per_octave) + 1
    return [f_min * (2 ** (i / points_per_octave)) for i in range(n)]


def evaluate_response(bands: List[dict], points_per_octave: int = 12) -> List[float]:
    """在对数频率网格上合成所有滤波器的近似响应（dB），返回与网格同长列表。"""
    return [
        sum(_band_gain_at(b, f) for b in bands) for f in _freq_grid(points_per_octave)
    ]


def compute_preamp(bands: List[dict]) -> float:
    """按 eq-design-guide.md 第 5 节：preamp = -(最大合成正增益) - 安全余量。"""
    max_pos = max(evaluate_response(bands) + [0.0])
    if max_pos <= 0:
        return 0.0
    return -(round(max_pos, 1) + LIMITS["preamp_margin_db"])


# ---------------------------------------------------------------------------
# 主计算入口
# ---------------------------------------------------------------------------
def _merge_bands(bands: List[dict]) -> List[dict]:
    """合并同类型且频率相近（<10%，约 1/16 倍频程内）的滤波器。

    依据 eq-design-guide.md 第 4 节"合成前合并"：避免设备修正与听感偏好
    在同一频率堆叠出冗余滤波器（如同频双 shelf），合并后增益取和、Q 取更宽者。

    扩展类型合并：类型 0/1/3/4/5 视为"主类型"参与合并；
    TYPE_GRAPHIC(2) 与其他类型不合并（始终保留为独立 graphic 频段）。
    """
    _MAIN = {TYPE_LOW_SHELF, TYPE_HIGH_SHELF, TYPE_PEAK, TYPE_EXT_PEAK, TYPE_EXT_HIGH_SHELF}
    merged: List[dict] = []
    for b in sorted(bands, key=lambda x: (x["frequency"], x["type"])):
        if merged and b["type"] in _MAIN:
            prev = merged[-1]
            freq_close = (
                abs(b["frequency"] - prev["frequency"])
                / max(prev["frequency"], b["frequency"], 1)
                < 0.1
            )
            if prev["type"] in _MAIN and freq_close and _same_main_type(prev["type"], b["type"]):
                prev["gain"] = round(prev["gain"] + b["gain"], 1)
                prev["q"] = round(min(prev["q"], b["q"]), 2)
                continue
        merged.append(dict(b))
    return merged


def _same_main_type(t1: int, t2: int) -> bool:
    """判断两个滤波器类型是否属于"同一主类"——用于同频合并判定。"""
    main = lambda t: (
        "peak" if t in _TYPE_AS_PEAK
        else "shelf" if t in _TYPE_AS_SHELF or t == TYPE_LOW_SHELF
        else f"other_{t}"
    )
    return main(t1) == main(t2)


def _clamp_gain(gain: float, warn_list: List[str], ctx: str) -> float:
    if abs(gain) > LIMITS["gain_abs_max"]:
        warn_list.append(
            f"{ctx}: 增益 {gain:+.1f} dB 超出 ±{LIMITS['gain_abs_max']:.0f} dB 上限，已钳制"
        )
        gain = math.copysign(LIMITS["gain_abs_max"], gain)
    elif abs(gain) > LIMITS["gain_abs_warn"]:
        warn_list.append(
            f"{ctx}: 增益 {gain:+.1f} dB 超过 ±{LIMITS['gain_abs_warn']:.0f} dB 警告线，请确认声学理由"
        )
    return gain


def _parse_preferences(preference: str, device_type: str) -> List[str]:
    keys = [p.strip() for p in preference.split(",") if p.strip()]
    if not keys:
        raise PeqError("preference 不能为空")
    for k in keys:
        if k not in PREFERENCE_LIBRARY:
            valid = ", ".join(sorted(PREFERENCE_LIBRARY))
            raise PeqError(f"未知听感偏好 '{k}'。可用偏好：{valid}")
        rule = PREFERENCE_LIBRARY[k]
        only = rule.get("only_for")
        if only and device_type not in only:
            raise PeqError(
                f"偏好 '{k}' 仅适用于 {only}（当前设备 '{device_type}'）"
            )
    if "balanced" in keys and len(keys) > 1:
        raise PeqError("balanced 为中性基准，不能与其他偏好组合")
    return keys


def _parse_custom_band(spec: str) -> dict:
    """解析自定义频段 'PK|LSC|HSC|GR 频率 增益 Q'，如 'PK 150 3.0 1.4'。

    扩展支持：PK+/HSC+ 通过 PK/HSC 别名进入；若需精确 4/5 类型，使用 --band 4/5 数字（CLI 适配）。
    """
    parts = spec.replace(",", " ").split()
    if len(parts) != 4:
        raise PeqError(
            f"自定义频段格式错误：'{spec}'，应为 'TYPE freq gain q'（如 'PK 150 3.0 1.4'）"
        )
    tname, freq, gain, q = parts[0].upper(), parts[1], parts[2], parts[3]
    type_map = {"PK": TYPE_PEAK, "LSC": TYPE_LOW_SHELF, "HSC": TYPE_HIGH_SHELF,
                "GR": TYPE_GRAPHIC, "PK+": TYPE_EXT_PEAK, "HSC+": TYPE_EXT_HIGH_SHELF}
    if tname not in type_map:
        raise PeqError(f"自定义频段类型 '{tname}' 无效，应为 PK/LSC/HSC/GR/PK+/HSC+")
    try:
        band = {
            "type": type_map[tname],
            "frequency": int(float(freq)),
            "gain": float(gain),
            "q": float(q),
        }
    except ValueError as exc:
        raise PeqError(f"自定义频段数值错误：'{spec}'（{exc}）") from exc
    return band


def compute_peq(
    device_type: str,
    preference: str,
    intensity: float = 1.0,
    custom_bands: Optional[List[str]] = None,
    genre_bands: Optional[List[dict]] = None,
) -> dict:
    """计算 PEQ 预设。

    返回 Poweramp Equalizer 预设结构：{name, preamp, parametric, bands}。
    bands: [{type, frequency, q, gain}]，frequency 为 int。
    同时通过返回值中的 "warnings" 携带校验信息（导出前须呈现给用户）。

    新增参数 genre_bands：音乐风格叠加层（来自 CLI 的 GENRE_LIBRARY 或自定义），
    在设备修正之后、偏好之后追加；intensity 同样作用于其增益；用于实现"风格×设备"组合。
    """
    if device_type not in DEVICE_LIBRARY:
        valid = "\n  ".join(f"{k}: {v['name']}" for k, v in DEVICE_LIBRARY.items())
        raise PeqError(f"未知设备类型 '{device_type}'。可用设备：\n  {valid}")

    if not (LIMITS["intensity_min"] <= intensity <= LIMITS["intensity_max"]):
        raise PeqError(
            f"intensity 必须在 {LIMITS['intensity_min']}-{LIMITS['intensity_max']} 之间"
        )

    pref_keys = _parse_preferences(preference, device_type)
    device = DEVICE_LIBRARY[device_type]
    warnings: List[str] = []

    # 1) 设备基准修正（先修正）
    bands = []
    for b in device["correction"]:
        bands.append(
            {
                "type": b["type"],
                "frequency": int(b["frequency"]),
                "q": round(float(b["q"]), 2),
                "gain": round(float(b["gain"]), 1),
            }
        )

    # 2) 听感偏好叠加（后调味），增益按 intensity 缩放
    for k in pref_keys:
        rule = PREFERENCE_LIBRARY[k]
        pref_bands = list(rule["bands"])
        if k == "bass_boost" and device_type in _IEM_DEVICE_KEYS:
            pref_bands += rule.get("extra_bands_iem", [])
        for b in pref_bands:
            gain = round(float(b["gain"]) * intensity, 1)
            gain = _clamp_gain(gain, warnings, f"偏好 {k}")
            bands.append(
                {
                    "type": b["type"],
                    "frequency": int(b["frequency"]),
                    "q": round(float(b["q"]), 2),
                    "gain": gain,
                }
            )

    # 2.5) 音乐风格叠加（CLI 传入的 genre_bands 列表；同样按 intensity 缩放）
    for b in (genre_bands or []):
        gain = round(float(b["gain"]) * intensity, 1)
        gain = _clamp_gain(gain, warnings, "风格叠加")
        bands.append(
            {
                "type": int(b["type"]),
                "frequency": int(b["frequency"]),
                "q": round(float(b["q"]), 2),
                "gain": gain,
            }
        )

    # 3) 用户自定义频段（最后追加，覆盖一切规则）
    for spec in custom_bands or []:
        b = _parse_custom_band(spec)
        _clamp_gain(b["gain"], warnings, f"自定义频段 {spec}")
        bands.append(b)

    # 4) 合并同频同类型滤波器 + 按频率排序
    bands = _merge_bands(bands)
    bands.sort(key=lambda b: b["frequency"])

    # 5) preamp 自动补偿（防削波）
    preamp = compute_preamp(bands)

    labels = " + ".join(PREFERENCE_LIBRARY[k]["label"] for k in pref_keys)
    preset = {
        "name": f"{device['name']} - {labels}",
        "preamp": preamp,
        "parametric": True,
        "bands": bands,
    }

    # 6) 声学合理性校验
    warnings.extend(validate_preset(preset))
    preset["warnings"] = warnings
    return preset


def validate_preset(preset: dict) -> List[str]:
    """声学合理性校验，返回警告/错误描述列表（详见 eq-design-guide.md 第 6 节）。"""
    issues: List[str] = []
    bands = preset.get("bands", [])
    preamp = float(preset.get("preamp", 0.0))

    if not bands:
        issues.append("警告: 预设没有任何滤波器频段")
        return issues

    if len(bands) > LIMITS["bands_max"]:
        issues.append(
            f"警告: 频段数 {len(bands)} 超过建议上限 {LIMITS['bands_max']}（主应用最多 128 段）"
        )

    for i, b in enumerate(bands, 1):
        t = b["type"]
        freq = b["frequency"]
        q = float(b["q"])
        gain = float(b["gain"])

        if t not in (TYPE_LOW_SHELF, TYPE_HIGH_SHELF, TYPE_PEAK, TYPE_GRAPHIC,
                     TYPE_EXT_PEAK, TYPE_EXT_HIGH_SHELF):
            issues.append(f"错误: 频段{i} 类型 {t} 无效（支持 0/1/2/3/4/5）")
        if not isinstance(freq, int) or not (LIMITS["freq_min"] <= freq <= LIMITS["freq_max"]):
            issues.append(
                f"错误: 频段{i} 频率 {freq} 无效（需整数且在 "
                f"{LIMITS['freq_min']}-{LIMITS['freq_max']} Hz）"
            )
        if t == TYPE_GRAPHIC:
            if abs(q) > 0.01:
                issues.append(f"警告: 频段{i} 为图示频段 (type=2)，Q 应为 0（实际 {q}）")
        elif t in _TYPE_AS_PEAK:
            if not (LIMITS["peak_q_min"] <= q <= LIMITS["peak_q_max"]):
                issues.append(
                    f"错误: 频段{i} peak Q={q} 超出 {LIMITS['peak_q_min']}-{LIMITS['peak_q_max']}"
                )
        else:  # shelf
            if not (LIMITS["shelf_q_min"] <= q <= LIMITS["shelf_q_max"]):
                issues.append(
                    f"错误: 频段{i} shelf Q={q} 超出 {LIMITS['shelf_q_min']}-{LIMITS['shelf_q_max']}"
                )
        if abs(gain) > LIMITS["gain_abs_max"]:
            issues.append(
                f"错误: 频段{i} 增益 {gain:+.1f} dB 超出 ±{LIMITS['gain_abs_max']:.0f} dB 硬上限"
            )

    # 合成响应检查：最大正增益 & preamp 是否足以防削波
    response = evaluate_response(bands)
    max_pos = max(response + [0.0])
    if max_pos > LIMITS["combined_gain_warn"]:
        issues.append(
            f"警告: 滤波器合成正增益达 {max_pos:+.1f} dB（{LIMITS['combined_gain_warn']:+.0f} dB 以上），"
            "建议降低增益或拆分频段"
        )
    if max_pos > 0 and preamp > -max_pos:
        issues.append(
            f"错误: preamp={preamp:.1f} dB 不足以抵消 {max_pos:+.1f} dB 合成正增益，会导致数字削波"
        )

    # 修正被抵消检测（同频对冲）
    for i in range(len(bands) - 1):
        a, b2 = bands[i], bands[i + 1]
        if (
            a["type"] == b2["type"] == TYPE_PEAK
            and abs(a["frequency"] - b2["frequency"]) / max(a["frequency"], 1) < 0.2
            and a["gain"] * b2["gain"] < 0
        ):
            issues.append(
                f"警告: 频段 {a['frequency']}Hz 与 {b2['frequency']}Hz 增益方向对冲，"
                "可能存在'修正被偏好抵消'，请复核"
            )

    return issues


# ---------------------------------------------------------------------------
# 导出渲染（严格对齐 references/poweramp-formats.md）
# ---------------------------------------------------------------------------
def render_poweramp_txt(preset: dict) -> str:
    """渲染 Poweramp 主应用可导入的 REW/APO 参数 .txt 内容。"""
    lines = [f"Preamp: {float(preset['preamp']):+.1f} dB"]
    for i, b in enumerate(preset["bands"], 1):
        lines.append(
            f"Filter {i}: ON {TYPE_NAME[b['type']]} "
            f"Fc {int(b['frequency'])} Hz "
            f"Gain {float(b['gain']):+.1f} dB "
            f"Q {float(b['q']):.2f}"
        )
    lines.append("")
    return "\n".join(lines)


def render_equalizer_json(preset: dict) -> str:
    """渲染 Poweramp Equalizer 可导入的 .json 内容（数组包裹、制表符缩进、频率取整）。

    支持 6 种滤波器类型与 graphic 模式（parametric=False）。所有非零字段
    （channels/color/type）均按 Poweramp 实际格式保留；缺失字段默认 0。
    """
    import json

    obj = {
        "name": preset["name"],
        "preamp": round(float(preset["preamp"]), 1),
        "parametric": bool(preset.get("parametric", True)),
        "bands": [
            {
                "type": int(b["type"]),
                "channels": int(b.get("channels", 0)),
                "frequency": int(b["frequency"]),
                "q": round(float(b["q"]), 2),
                "gain": round(float(b["gain"]), 1),
                "color": int(b.get("color", 0)),
            }
            for b in preset["bands"]
        ],
    }
    # ensure_ascii=False 保留中文预设名；缩进用制表符（格式规范要求）
    return json.dumps([obj], ensure_ascii=False, indent="\t")


def parse_preset(obj: dict) -> dict:
    """将一个预设 dict（如从库导入或 Poweramp 导出 JSON 反序列化所得）规范化。

    接受 {name, preamp, parametric, bands[{type, channels, frequency, q, gain, color}, ...]} 结构，
    返回同结构（含可选 channels/color 字段），用于在技能内继续处理与重新渲染。
    不修改字段语义——本函数只做类型归一化与缺省值补齐。
    """
    if not isinstance(obj, dict):
        raise PeqError(f"预设对象必须是 dict，实际 {type(obj).__name__}")
    if "bands" not in obj:
        raise PeqError("预设对象缺少 'bands' 字段")
    bands = []
    for b in obj["bands"]:
        if not isinstance(b, dict):
            raise PeqError(f"bands 项必须是 dict，实际 {type(b).__name__}")
        if "type" not in b or "frequency" not in b or "gain" not in b or "q" not in b:
            raise PeqError(f"bands 项缺少必要字段：{b}")
        bands.append({
            "type": int(b["type"]),
            "channels": int(b.get("channels", 0)),
            "frequency": int(b["frequency"]),
            "q": round(float(b["q"]), 2),
            "gain": round(float(b["gain"]), 1),
            "color": int(b.get("color", 0)),
        })
    return {
        "name": str(obj.get("name", "")),
        "preamp": round(float(obj.get("preamp", 0.0)), 1),
        "parametric": bool(obj.get("parametric", True)),
        "bands": bands,
    }


def parse_library_file(path: str) -> List[dict]:
    """读取 Poweramp 预设库 JSON 文件（数组包裹多预设），返回规范化后的预设列表。

    单个元素不是 dict 时自动跳过；其余错误抛出 PeqError。文件可能很大（10k+ 预设），
    调用方负责缓存或流式处理。
    """
    import json
    import os

    if not os.path.isfile(path):
        raise PeqError(f"找不到 Poweramp 预设库文件：{path}")
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as exc:
        raise PeqError(f"Poweramp 预设库 JSON 解析失败：{exc}") from exc
    if not isinstance(data, list):
        raise PeqError("预设库文件根元素必须是数组")
    presets = []
    for i, item in enumerate(data):
        if isinstance(item, dict) and "bands" in item:
            try:
                presets.append(parse_preset(item))
            except PeqError:
                continue  # 跳过无法解析的项，不中断整体加载
    return presets


def has_errors(issues: List[str]) -> bool:
    return any(i.startswith("错误") for i in issues)


if __name__ == "__main__":
    demo = compute_peq("iem_dynamic", "bass_boost", 1.0)
    print(render_poweramp_txt(demo))
    print(render_equalizer_json(demo))
