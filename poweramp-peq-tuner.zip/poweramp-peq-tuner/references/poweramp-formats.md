# Poweramp 官方预设格式规范

本文件为 `poweramp-peq-tuner` 技能的格式基准。导出的预设文件必须严格遵循以下两种规范之一，才能被 Poweramp 官方应用识别为有效预设。

## 1. 两种应用、两种格式

| 应用 | 导入格式 | 导入路径 |
|---|---|---|
| Poweramp（主应用，build 909+） | `.txt`（REW / EqualizerAPO 参数格式） | 右上角三点菜单 → Equalizer → Presets → Import → 选择 .txt 文件 |
| Poweramp Equalizer（独立均衡器应用） | `.json`（预设对象数组） | 应用内预设列表 → Import → 选择 .json 文件 |

同一套滤波器参数（频率/增益/Q/类型）可同时渲染为两种格式，内容等价。

## 2. Poweramp 主应用：`.txt` 格式（REW/APO 参数格式）

### 2.1 文件结构

纯文本文件，逐行定义。第一行为可选的前级增益，随后每个滤波器一行：

```
Preamp: -2.5 dB
Filter 1: ON LSC Fc 90 Hz Gain 3.0 dB Q 0.70
Filter 2: ON PK Fc 1000 Hz Gain -1.5 dB Q 1.41
Filter 3: ON HSC Fc 10000 Hz Gain 2.0 dB Q 0.70
```

### 2.2 字段规范

| 字段 | 说明 |
|---|---|
| `Preamp: X dB` | 前级增益，浮点数，单位 dB。**必须为非正值**（见 2.4 削波说明） |
| `Filter N:` | 滤波器序号，从 1 开始连续递增 |
| `ON` / `OFF` | 启用状态，导出时一律用 `ON` |
| 滤波器类型 | `PK` 峰值（Bell）；`LSC` 低架（Low Shelf）；`HSC` 高架（High Shelf）。主应用解析 AutoEQ/REW 导出的这三种类型 |
| `Fc N Hz` | 中心/转角频率，整数 Hz，20–20000 |
| `Gain N dB` | 增益，浮点 dB，建议 ±10 dB 以内 |
| `Q N` | 品质因数，浮点。peak 建议 0.4–5.0；shelf 建议 0.5–0.9 |

### 2.3 频段数量

- 主应用导入后频段自动加载，单个预设最多 **128 段**。
- 常规调音建议 5–10 段即可，超过 16 段对听感收益极低且难以维护。

### 2.4 削波（Clipping）警告

正增益滤波器叠加会推高总输出电平导致数字削波。**必须**将 `Preamp` 设为非正值，推荐：

```
preamp = -（所有滤波器在任一频率处的最大合成正增益），并向下取 0.5 dB 安全余量
```

`peq_engine.py` 会自动计算并写入该值，禁止手工置 0 而忽略叠加增益。

## 3. Poweramp Equalizer：`.json` 格式

### 3.1 文件结构

JSON **数组**包裹单个预设对象（即使只有一个预设也必须是数组），缩进使用制表符（`\t`）：

```json
[
	{
		"name": "IEM - Bass Boost",
		"preamp": -3.5,
		"parametric": true,
		"bands": [
			{ "type": 0, "channels": 0, "frequency": 90, "q": 0.7, "gain": 4.0, "color": 0 },
			{ "type": 3, "channels": 0, "frequency": 1000, "q": 1.41, "gain": -1.5, "color": 0 },
			{ "type": 1, "channels": 0, "frequency": 10000, "q": 0.7, "gain": 2.0, "color": 0 }
		]
	}
]
```

### 3.2 预设对象字段

| 键 | 类型 | 说明 |
|---|---|---|
| `name` | string | 预设名称，导入后在应用中显示 |
| `preamp` | float | 前级增益（dB），非正值防削波 |
| `parametric` | bool | 固定 `true`（参数化均衡标记） |
| `bands` | array | 滤波器频段数组 |

### 3.3 band 对象字段

| 键 | 类型 | 说明 |
|---|---|---|
| `type` | int | 滤波器类型标记（详见 3.4 完整对照） |
| `channels` | int | 固定 `0`（全部声道） |
| `frequency` | int | 频率，**必须为整数** Hz（渲染前对浮点取整），20–20000 |
| `q` | float | Q 值 |
| `gain` | float | 增益（dB） |
| `color` | int | 频段显示颜色，固定 `0` 即可（应用会自动分配） |

### 3.4 type ↔ .txt 类型完整对照

> **重要更新**：Poweramp Equalizer 实际支持 6 种类型（通过 `settings/Poweramp自带默认配置.json` 10025 条预设反推）。

| .txt | .json type | 含义 | Q 要求 | 适用场景 |
|---|---|---|---|---|
| `LSC` | `0` | 低架（Low Shelf） | 0.5–0.9 | 低频平台补低频 |
| `HSC` | `1` | 高架（High Shelf） | 0.5–0.9 | 高频空气感 |
| `GR` | `2` | 图示频段（Graphic band） | **必须 0** | `parametric=false` 图示模式（32 段 graphic EQ 滑条） |
| `PK` | `3` | 峰值（Peak/Bell） | 0.4–5.0 | 通用参数 EQ |
| `PK+` | `4` | 扩展峰值（Extended peak） | 0.4–5.0 | 32 段 AutoEQ 设备预设常用（行为等同 PK） |
| `HSC+` | `5` | 扩展高架（Extended high shelf） | 0.5–0.9 | 32 段 AutoEQ 设备预设常用（行为等同 HSC） |

> 本技能引擎在 `validate_preset` 中识别 0/1/2/3/4/5 全 6 类；合成响应评估时 type 4→按 peak 近似、type 5→按 high shelf 近似、type 2 返回 0（graphic 响应由 EQ 实时合成）。

### 3.5 parametric 字段

- `true`（默认）：参数化 EQ 模式——应用显示可调 Q/类型的频段
- `false`：图示 EQ 模式——bands 中可同时存在 LSC/HSC 与多个 type=2 graphic 滑条

> Poweramp 内置 18 条经典风格预设（Bass/Treble/Rock/Classical 等）均为 `parametric=false`、12 段图示（10 个 type=2 + LSC + HSC）。
> 设备专用 AutoEQ 库 5000+ 条为 32 段图示（30 个 type=2 + LSC + HSC，部分含 type=4/5）。

## 4. 兼容性注意事项（导出前必查）

1. **JSON 必须是数组**：忘记用 `[ ]` 包裹单对象是最常见导入失败原因。
2. **frequency 必须取整**：`.json` 中写入浮点频率（如 `87.5`）会导致解析失败；`.txt` 中同样用整数。
3. **preamp 削波**：任何正增益方案必须带负 preamp（见 2.4）。
4. **Q 与频率范围**：peak Q 0.4–5.0、shelf Q 0.5–0.9、type=2 graphic Q 必须 0；频率 20–20000 Hz 之外的值属于无效预设。
5. **编码与换行**：`.txt` 使用 UTF-8 无 BOM、`\n` 换行；文件名避免特殊字符。

---

## 5. 技能 API：解析与往返

`peq_engine.py` 提供 4 个面向 Poweramp JSON 格式的解析与渲染 API：

```python
from peq_engine import (
    render_equalizer_json,   # 预设 dict -> .json 字符串
    parse_preset,            # 预设 dict -> 归一化预设 dict（补 channels/color 缺省）
    parse_library_file,      # 路径 -> 库预设列表（用于 search/load）
    render_poweramp_txt,     # 预设 dict -> .txt 字符串
)
```

### 5.1 解析 Poweramp 导出的 JSON 文件

```python
import json
with open("my_poweramp_export.json", encoding="utf-8") as f:
    raw = json.load(f)         # 必须是数组
presets = [parse_preset(p) for p in raw]
```

### 5.2 读取 Poweramp 自带默认配置库（用于 search-headphone / apply-headphone）

```python
presets = parse_library_file("settings/Poweramp自带默认配置.json")
# presets 是 list[dict]，每个 dict 是 {name, preamp, parametric, bands}
```

### 5.3 完整往返示例

```python
from peq_engine import (
    parse_library_file, render_equalizer_json, parse_preset, validate_preset
)
# 1) 从库加载 BGVP Scale 设备预设
lib = parse_library_file("settings/Poweramp自带默认配置.json")
bgvp = next(p for p in lib if p["name"] == "BGVP Scale")
# 2) 校验（不阻断，仅返回 warnings）
issues = validate_preset(bgvp)
# 3) 渲染为 .json 字符串
print(render_equalizer_json(bgvp))
# 4) 解析回来验证无字段丢失
roundtrip = parse_preset(json.loads(render_equalizer_json(bgvp))[0])
assert roundtrip["parametric"] == bgvp["parametric"]
assert len(roundtrip["bands"]) == len(bgvp["bands"])
```

> 往返保真度：所有非零字段（channels/color/type）均按 Poweramp 实际格式保留，
> 缺失字段默认 0；graphic 频段（type=2）完整保留并由应用按图示模式渲染。
6. **增益幅度**：单段增益超过 ±10 dB 通常意味着选错了滤波器类型（应改用 shelf 或拆分多段）。
7. **传输方式**：将导出文件复制/发送到手机存储后，在应用内通过 Import 菜单选择文件；不要尝试放入应用私有目录替换数据库。

## 5. 格式来源与可信度

- `.json` 字段结构核实自开源转换工具 AutoEQApoToPowerampEQ（GitHub, AdamRopelewski）的源码：顶层键 `name/preamp/parametric/bands`，band 键 `type/channels/frequency/q/gain/color`，type 映射 0/1/3。
- `.txt` 格式核实自 AutoEQ-Parametric-8-128-band（GitHub, DAPAAADF）项目及 AutoEQ 社区通用做法：Poweramp 主应用 Presets → Import 接受 REW/APO 参数文本，最多 128 段。
- 若未来 Poweramp 官方格式变更，以 https://forum.powerampapp.com 的官方说明为准，并同步更新本文件与 `peq_engine.py` 的渲染逻辑。
