# 音乐风格库（Genre Library）

> 与 `device-profiles.md` 中的"设备规则库"配合使用：设备修正保证硬件频响平直，
> 音乐风格在此之上叠加"调音偏好"。每条风格由目标曲线描述 + 适用场景 + 与设备叠加方法组成。

---

## 1. 设计原则

| 原则 | 说明 |
|---|---|
| 后叠加 | 风格必须在设备修正**之后**应用（先平直、再调味） |
| 强度可调 | `intensity` 0.5–2.0 线性缩放风格所有增益（与偏好一致） |
| 不破削 | 引擎对风格增益同样执行 ±10 dB 钳制与 preamp 重算防削波 |
| 风格非库 | 本库是抽象的"目标曲线"，**不直接复用** Poweramp 内置 graphic 预设的 filter 表；<br>Poweramp 内置预设更适合直接 `load-library-preset` 加载使用 |

---

## 2. 内置 14 条风格

| Key | 风格 | 调音特征 | 适合音乐 |
|---|---|---|---|
| `rock` | 摇滚 | 低频鼓点饱满+中高频吉它/人声前移 | 摇滚、金属、朋克 |
| `pop` | 流行 | V 形——低频稍抬+高频通透，人声自然 | 流行、City Pop |
| `classical` | 古典 | 频响平直、低频大提琴丰满、高频弦乐顺滑 | 古典、室内乐 |
| `jazz` | 爵士 | 中频厚实（萨克斯/钢琴）、低频紧凑、高频不刺 | 爵士、布鲁斯 |
| `dance` | 电子舞曲 | 低频重击+超高频亮——俱乐部 | EDM、House |
| `techno` | Techno | 极低频突出、中频压暗、高频清脆 | Techno、Industrial |
| `live` | Live 现场 | 保留现场感与早期反射，中频饱满 | 现场录音 |
| `soft` | 轻柔 | 整体温和、齿音收敛、长时间不疲劳 | 夜晚、轻音乐 |
| `loudness` | 响度补偿 | 小音量下补回 Fletcher-Munson 两端损失 | 低音量聆听 |
| `vocal` | 纯人声/播客 | 1-5kHz 突出人声、低高频收敛 | 播客、ASMR |
| `flat` | 原声平直 | 仅设备修正，不叠加风格 | 参考基线 |
| `bass_extreme` | 低频极端 | 强低频强化（preamp -2.4 dB 守削波） | 派对、低音狂 |
| `treble` | 高音强化 | 高频空气感+镲片亮、低频略收 | 古典、HiFi 测试 |
| `speaker_loud` | 扬声器响亮 | 全频段 +3dB 配合 +7.2dB preamp | 手机/小音箱外放 |

> 查看引擎内置定义：`peq_cli.py list-genres`

---

## 3. 与设备修正叠加方法

### 3.1 命令行（推荐）

```bash
# 例：HD800 听古典
python peq_cli.py create-profile \
    --name 古典HD800 \
    --device-type open_headphone \
    --preference balanced \
    --genre classical

# 例：BGVP Scale 听摇滚（叠加库设备修正 + 风格）
python peq_cli.py apply-headphone \
    --name BGVP_Scale_摇滚 \
    --headphone "BGVP Scale" \
    --genre rock
```

### 3.2 设计顺序（重要）

1. **设备修正**：先按 `device-profiles.md` 选定设备类型
2. **听感偏好**（可选）：`bass_boost / vocal_forward / treble_airy / reduce_harshness / warm / soundstage`
3. **音乐风格**（可选）：本库的 14 条之一
4. **自定义频段**（可选）：`--custom-band` 追加

风格放在**偏好之后**叠加，引擎合并 → 排序 → 重算 preamp。

### 3.3 强度控制

```bash
# 减半强度（轻度调味）
python peq_cli.py create-profile --name 半古典 --device-type open_headphone \
    --preference balanced --genre classical --intensity 0.6

# 加倍（重口味，preamp 重新负向补偿）
python peq_cli.py create-profile --name 重摇滚 --device-type iem_dynamic \
    --preference bass_boost --genre rock --intensity 1.6
```

---

## 4. 与 Poweramp 内置 graphic 风格预设的区别

| 维度 | 本技能内置风格（GENRE_LIBRARY） | Poweramp 内置预设（如 "Rock"、"Bass"） |
|---|---|---|
| 渲染方式 | 抽象目标曲线 → 规则库换算为 PEQ 频段 | 完整 graphic 32 段 EQ 滑条（type=2） |
| 设备耦合 | 可与设备修正叠加 | 独立配置，需手动与设备修正组合 |
| 调整粒度 | 4–6 个 PEQ 段 | 32 个 graphic 滑条 |
| 导入方式 | 走本技能 PEQ 路径（txt / Equalizer json） | 走 Equalizer json 路径（图形模式） |
| 适用场景 | 设备修正 + 风格调味组合 | 快速听某类音乐、对 PEQ 不熟 |

**建议**：本技能用于精准调音（设备 + 风格分层）；Poweramp 内置预设用于即开即用。
当用户的"Poweramp自带默认配置.json"中存在与设备型号匹配的预设时，
`apply-headphone` 会自动使用测量级库曲线作为设备修正基线，再叠加风格——精度远高于手搓规则库。

---

## 5. 风格 × 设备类型推荐矩阵

| 风格 \\ 设备 | iem_dynamic | iem_hybrid | open_headphone | bluetooth_headphone | car_audio | phone_speaker |
|---|---|---|---|---|---|---|
| rock | ★★ | ★★ | ★★★ | ★★ | ★★ | ★ |
| pop | ★★★ | ★★★ | ★★ | ★★★ | ★★★ | ★★★ |
| classical | ★★ | ★★★ | ★★★ | ★★ | ★ | — |
| jazz | ★★★ | ★★★ | ★★★ | ★★ | ★★ | ★ |
| dance | ★★ | ★★ | ★ | ★★ | ★★ | ★★ |
| live | ★★ | ★★★ | ★★★ | ★★ | ★★ | ★ |
| soft | ★★★ | ★★★ | ★★★ | ★★★ | ★★★ | ★★★ |
| vocal | ★★★ | ★★ | ★★ | ★★★ | ★★★ | ★★ |
| bass_extreme | ★ | ★★ | — | ★ | ★★ | — |
| treble | ★★ | ★★ | ★★★ | ★ | — | — |
| speaker_loud | — | — | — | — | — | ★★★ |

> ★★★=首选 / ★★=可用 / ★=次选 / —=不推荐
> 该矩阵为经验值；用户实际听感为最终判据，建议用 A/B 验证。
