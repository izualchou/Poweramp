---
name: poweramp-peq-tuner
description: Poweramp 参数均衡器（PEQ）调优技能。当用户要求为耳机、IEM、耳塞、头戴、音箱、监听音箱或车载音响设计/调优均衡器方案，生成可导入 Poweramp 或 Poweramp Equalizer 的预设文件（.txt/.json），管理多设备 EQ 配置档案，查询或加载 Poweramp 自带的 10000+ 条设备/风格预设库（AutoEQ 测量级），或询问 Poweramp 预设格式/导入方法时使用此技能。触发表述示例："帮我给这个耳机调 EQ"、"生成 Poweramp 预设"、"车载音响怎么调均衡器"、"导入 PEQ 配置"、"我用的 BGVP Scale 库里有吗"、"加载库里的 HD800 预设"、"给古典乐调个 EQ"。
---

# Poweramp PEQ 调优

## 概述

本技能根据音响设备类型、频响特性、用户听感偏好与音乐风格，自动设计声学合理的 PEQ（参数均衡器）方案，生成可直接导入 Poweramp 主应用与 Poweramp Equalizer 的官方兼容预设文件，并管理工作区内多设备配置档案。

**核心原则：**
- **确定性计算**——参数一律由 `scripts/` 中脚本计算生成，不靠模型临场编造
- **多源数据**——`peq_engine.DEVICE_LIBRARY`（手搓规则库）、Poweramp 自带 `settings/Poweramp自带默认配置.json`（10,025 条 AutoEQ 测量级 + 风格预设库）、`peq_cli.GENRE_LIBRARY`（14 条内置音乐风格）三类数据源协同
- **库优先**——设备有库预设时优先用 `apply-headphone`，比规则库精度高 1-2 个数量级
- **双格式导出**——同份 preset 同时渲染为 `.txt`（Poweramp 主应用 Presets→Import）与 `.json`（Poweramp Equalizer 预设 Import）

## 工作流决策树

```
用户请求
├─ 询问格式/导入方法 ──────────────→ 读 references/poweramp-formats.md 后解答
├─ 询问设备声学特征/选型 ──────────→ 读 references/device-profiles.md 后解答
├─ 设计/调整 PEQ 方案 ─────────────┐
│   1. 设备在 Poweramp 库中？
│      ├─ 是 → peq_cli search-headphone <型号> 确认 → apply-headphone (测量级)
│      └─ 否 → peq_cli create-profile --device-type <类型> (规则库)
│   2. 叠加听感偏好（--preference）与/或音乐风格（--genre）
│   3. 导出双格式：peq_cli export --profile <名> --target both
└─ 管理已有方案 ──────────────────→ list-profiles / show-profile / set-active / delete-profile
```

## 任务指引

### 任务 1：设计 PEQ 方案

```bash
# 1) 列出可用设备类型与听感偏好
python <skill-dir>/scripts/peq_cli.py list-devices
python <skill-dir>/scripts/peq_cli.py list-genres

# 2A) 库优先（设备有 AutoEQ 测量曲线时）
python <skill-dir>/scripts/peq_cli.py search-headphone "BGVP Scale" --device-only
python <skill-dir>/scripts/peq_cli.py apply-headphone --name "BGVP_Scale_古典" \
    --headphone "BGVP Scale" --genre classical --out exports

# 2B) 规则库基准（设备无库预设时，如 Sennheiser HD800）
python <skill-dir>/scripts/peq_cli.py create-profile --name 主力HD800 \
    --device-type open_headphone --preference balanced \
    --custom-band "PK 6500 -2.5 4.32" \
    --custom-band "LSC 110 4.0 0.70" \
    --brand Sennheiser --model HD800

# 3) 组合：库设备 + 风格 + 自定义微调
python <skill-dir>/scripts/peq_cli.py create-profile --name 日常IEM \
    --device-type iem_hybrid --preference vocal_forward --genre jazz --intensity 0.8
```

**`--preference`（听感偏好，逗号组合）**：`bass_boost / vocal_forward / treble_airy / reduce_harshness / warm / soundstage / balanced / road_noise_high（仅 car_audio）`

**`--genre`（音乐风格，与偏好叠加）**：`rock / pop / classical / jazz / dance / techno / live / soft / loudness / vocal / flat / bass_extreme / treble / speaker_loud`

**`--custom-band`**：追加 `TYPE freq gain q` 频段，类型支持 `PK / LSC / HSC / GR / PK+ / HSC+`

### 任务 2：多设备档案管理

```bash
python <skill-dir>/scripts/peq_cli.py list-profiles
python <skill-dir>/scripts/peq_cli.py show-profile --name 主力IEM
python <skill-dir>/scripts/peq_cli.py set-active --name 主力IEM
python <skill-dir>/scripts/peq_cli.py delete-profile --name 旧耳机 --yes
```

档案存于当前工作区 `peq-profiles/`（每设备一个 JSON）。`locked: true` 档案（如 31 段定制方案）跳过重算、`edit-profile` 拒绝修改以保护设计。

### 任务 3：一键导出

```bash
python <skill-dir>/scripts/peq_cli.py export --profile active --target both --out exports
```

- `--target poweramp` 导出 `.txt`（主应用 Equalizer → Presets → Import）
- `--target equalizer` 导出 `.json`（Poweramp Equalizer 预设 Import）；默认 `both`
- 导出前脚本会重算并执行声学校验；存在"错误"级问题时中止导出；"警告"级问题须转述

### 任务 4：Poweramp 库查询与加载

```bash
# 列出音乐风格
python <skill-dir>/scripts/peq_cli.py list-genres

# 在库（settings/Poweramp自带默认配置.json，10025 条）中按子串搜索
python <skill-dir>/scripts/peq_cli.py search-headphone "Sennheiser" --device-only --limit 30

# 直接加载某条库预设并双格式导出（无损往返）
python <skill-dir>/scripts/peq_cli.py load-library-preset --name "Rock" --out exports

# 组合库设备修正 + 风格 → 生成新档案
python <skill-dir>/scripts/peq_cli.py apply-headphone --name "Aero_Pop" \
    --headphone "1MORE Aero (ANC Off)" --genre pop --out exports
```

> 库路径配置：默认 `./settings/Poweramp自带默认配置.json`；环境变量 `POWERAMP_PRESETS_JSON` 可覆盖指向用户真实库文件。
> 库预设同名变体（同一设备多组参数）：CLI 取首条并打印提示，用户可读 `search-headphone` 列表精确挑选。

## 声学合理性约束（必须遵守）

- 单段增益 ±10 dB 硬上限（±6 dB 需有明确理由）
- 类型 Q 范围：peak 0.4–5.0、shelf 0.5–0.9、graphic（type=2）必须 0
- 频率 20–20000 Hz 整数；预置频段数建议 ≤10、上限 16（graphic 模式 32 段除外）
- preamp 由引擎按合成响应自动负向补偿防削波（库 graphic 预设保留原 preamp；本技能自算 preset 强制负向）
- 设计顺序：先设备基准修正 → 听感偏好 → 音乐风格 → 自定义频段；避免同频对冲
- 提供测量数据（AutoEQ/APO 文本、CSV、库中已存在的预设）时按测量数据设计

## 资源索引

| 资源 | 用途 |
|---|---|
| `scripts/peq_engine.py` | 确定性计算引擎：6 种滤波器类型、12 类设备规则库、8 种听感偏好、合成响应评估、preamp 补偿、校验、双格式渲染、库文件解析 |
| `scripts/peq_cli.py` | 档案管理与导出 CLI：create/list/show/edit/set-active/delete/export + list-genres/search-headphone/load-library-preset/apply-headphone |
| `references/poweramp-formats.md` | 6 种 type、parametric/graphic 双模式、channels/color 字段、import 解析与往返 API |
| `references/device-profiles.md` | 设备类型 → 频响特征 → 修正滤波器规则库；含 AutoEQ 库优先策略、库中无设备回退方法 |
| `references/eq-design-guide.md` | 听感偏好 → 滤波器设计原则、Q/增益经验值、preamp 法则、复核清单 |
| `references/genre-presets.md` | 14 条内置音乐风格、调音特征、与设备修正叠加方法、风格×设备类型推荐矩阵 |
| `assets/profile-template.json` | 设备档案 JSON 结构模板 |
| `assets/example-exports/` | 合法导出示例（.txt 与 .json），格式基准 |
| 用户库（外部）`settings/Poweramp自带默认配置.json` | 10025 条 Poweramp 自带预设（5000+ AutoEQ + 18 风格 + 变体） |

## 升级记录

### v2（当前）—— 库感知与风格系统

- **引擎扩展**：支持 Poweramp 全部 6 种滤波器类型（0/1/2/3/4/5），graphic 模式（`parametric: false`）、`channels`、`color` 字段完整往返
- **新增 `parse_preset` / `parse_library_file` API**：从用户 Poweramp 库导入测量级 AutoEQ 预设
- **CLI 新增 4 个子命令**：
  - `list-genres` 列出 14 条音乐风格
  - `search-headphone <关键词>` 在 10,025 条库中按子串搜索
  - `load-library-preset --name <精确名>` 无损往返导出
  - `apply-headphone --headphone <型号> --genre <风格>` 组合库设备修正 + 风格
- **新增 `--genre` 参数**：`create-profile` 现在支持音乐风格叠加（与 `--preference` 互补叠加）
- **新增 `references/genre-presets.md`**：14 条风格的设计原则、特征、推荐矩阵
- **文档更新**：
  - `poweramp-formats.md` 新增 type=2/4/5 完整对照、parametric 双模式、`parse_preset`/`parse_library_file` 往返 API
  - `device-profiles.md` 新增"AutoEQ 库优先策略"章节与库中无设备回退方法

### v1 — 基础能力

- 12 类设备规则库 + 8 种听感偏好 + 双格式导出
- 多设备档案管理（工作区 `peq-profiles/`）
- preamp 自动补偿防削波
- 声学校验（增益/Q/频段数/对冲检测）
